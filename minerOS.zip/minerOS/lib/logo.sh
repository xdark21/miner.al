Crypto Currency Mining Operating System 

